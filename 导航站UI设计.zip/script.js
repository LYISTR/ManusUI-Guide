// 导航栏交互功能
document.addEventListener('DOMContentLoaded', function() {
    // 导航栏滚动效果
    const nav = document.querySelector('.nav-container');
    let lastScrollTop = 0;
    
    window.addEventListener('scroll', function() {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // 添加滚动阴影效果
        if (scrollTop > 10) {
            nav.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
        } else {
            nav.style.boxShadow = 'none';
        }
        
        lastScrollTop = scrollTop;
    });
    
    // 平滑滚动到锚点
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - nav.offsetHeight,
                    behavior: 'smooth'
                });
                
                // 关闭可能打开的下拉菜单
                document.querySelectorAll('.dropdown-content').forEach(dropdown => {
                    dropdown.style.display = 'none';
                });
            }
        });
    });
    
    // 下拉菜单交互
    const navItems = document.querySelectorAll('.nav-item');
    
    navItems.forEach(item => {
        const dropdownBtn = item.querySelector('.nav-dropdown-btn');
        const dropdownContent = item.querySelector('.dropdown-content');
        
        if (dropdownBtn && dropdownContent) {
            // 点击按钮切换下拉菜单
            dropdownBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                
                // 关闭其他打开的下拉菜单
                document.querySelectorAll('.dropdown-content').forEach(dropdown => {
                    if (dropdown !== dropdownContent) {
                        dropdown.style.display = 'none';
                    }
                });
                
                // 切换当前下拉菜单
                if (dropdownContent.style.display === 'block') {
                    dropdownContent.style.display = 'none';
                } else {
                    dropdownContent.style.display = 'block';
                }
            });
        }
    });
    
    // 点击页面其他区域关闭下拉菜单
    document.addEventListener('click', function() {
        document.querySelectorAll('.dropdown-content').forEach(dropdown => {
            dropdown.style.display = 'none';
        });
    });
    
    // 卡片悬停效果增强
    const cards = document.querySelectorAll('.card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px)';
            this.style.boxShadow = '0 12px 30px rgba(0, 0, 0, 0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.05)';
        });
    });
    
    // 搜索功能（简单模拟）
    const searchLink = document.querySelector('.nav-search');
    
    if (searchLink) {
        searchLink.addEventListener('click', function(e) {
            e.preventDefault();
            
            // 创建搜索弹窗
            const searchOverlay = document.createElement('div');
            searchOverlay.className = 'search-overlay';
            searchOverlay.innerHTML = `
                <div class="search-container">
                    <input type="text" class="search-input" placeholder="搜索网站..." autofocus>
                    <button class="search-close">×</button>
                </div>
            `;
            
            document.body.appendChild(searchOverlay);
            document.body.style.overflow = 'hidden';
            
            // 添加搜索弹窗样式
            const style = document.createElement('style');
            style.textContent = `
                .search-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.9);
                    z-index: 2000;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    animation: fadeIn 0.3s;
                }
                
                .search-container {
                    width: 80%;
                    max-width: 600px;
                    position: relative;
                }
                
                .search-input {
                    width: 100%;
                    padding: 15px 20px;
                    font-size: 18px;
                    border: none;
                    border-radius: 8px;
                    background-color: rgba(255, 255, 255, 0.1);
                    color: white;
                    outline: none;
                }
                
                .search-close {
                    position: absolute;
                    right: -40px;
                    top: 50%;
                    transform: translateY(-50%);
                    background: none;
                    border: none;
                    color: white;
                    font-size: 30px;
                    cursor: pointer;
                }
            `;
            
            document.head.appendChild(style);
            
            // 关闭搜索弹窗
            const closeBtn = document.querySelector('.search-close');
            closeBtn.addEventListener('click', function() {
                document.body.removeChild(searchOverlay);
                document.body.style.overflow = '';
            });
            
            // ESC键关闭搜索弹窗
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    if (document.querySelector('.search-overlay')) {
                        document.body.removeChild(searchOverlay);
                        document.body.style.overflow = '';
                    }
                }
            });
        });
    }
    
    // 移动端菜单按钮（添加响应式支持）
    const createMobileMenu = function() {
        if (window.innerWidth <= 768 && !document.querySelector('.mobile-menu-btn')) {
            const navRight = document.querySelector('.nav-right');
            const navMenu = document.querySelector('.nav-menu');
            
            // 创建移动端菜单按钮
            const mobileMenuBtn = document.createElement('button');
            mobileMenuBtn.className = 'mobile-menu-btn';
            mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            
            // 插入到导航右侧区域
            navRight.insertBefore(mobileMenuBtn, navRight.firstChild);
            
            // 添加移动端菜单样式
            const style = document.createElement('style');
            style.textContent = `
                .mobile-menu-btn {
                    display: block;
                    background: none;
                    border: none;
                    color: white;
                    font-size: 18px;
                    cursor: pointer;
                    margin-right: 15px;
                }
                
                @media (max-width: 768px) {
                    .nav-menu {
                        position: absolute;
                        top: var(--nav-height);
                        left: 0;
                        width: 100%;
                        background-color: var(--nav-bg-color);
                        flex-direction: column;
                        display: none;
                        padding: 10px 0;
                        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
                    }
                    
                    .nav-menu.active {
                        display: flex;
                    }
                    
                    .nav-item {
                        margin: 0;
                        width: 100%;
                    }
                    
                    .nav-link {
                        padding: 15px 20px;
                        width: 100%;
                        justify-content: center;
                        height: auto;
                    }
                    
                    .nav-dropdown-btn {
                        position: absolute;
                        right: 20px;
                        height: auto;
                    }
                    
                    .dropdown-content {
                        position: static;
                        width: 100%;
                        transform: none;
                        box-shadow: none;
                        background-color: rgba(0, 0, 0, 0.2);
                    }
                }
            `;
            
            document.head.appendChild(style);
            
            // 移动端菜单切换
            mobileMenuBtn.addEventListener('click', function() {
                navMenu.classList.toggle('active');
            });
        } else if (window.innerWidth > 768 && document.querySelector('.mobile-menu-btn')) {
            // 移除移动端菜单按钮
            const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
            mobileMenuBtn.parentNode.removeChild(mobileMenuBtn);
            
            // 重置菜单状态
            const navMenu = document.querySelector('.nav-menu');
            navMenu.classList.remove('active');
            navMenu.style.display = '';
        }
    };
    
    // 初始化移动端菜单
    createMobileMenu();
    
    // 窗口大小变化时重新检查
    window.addEventListener('resize', createMobileMenu);
});
